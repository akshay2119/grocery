package com.grocerystore.dao;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.grocerystore.entity.Items;

@Repository
public interface GroceryStoreDao extends CrudRepository<Items, Integer> {

	public Items save(String itemname);

	public ArrayList<Items> findByCategory(String category);


}
