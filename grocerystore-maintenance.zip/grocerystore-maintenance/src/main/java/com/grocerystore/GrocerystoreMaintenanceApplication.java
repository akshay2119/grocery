package com.grocerystore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ConfigurableApplicationContext;

import com.grocerystore.service.GroceryStoreService;


@SpringBootApplication
public class GrocerystoreMaintenanceApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext applicationContext=SpringApplication.run(GrocerystoreMaintenanceApplication.class, args);
		
		GroceryStoreService groceryStoreService=applicationContext.getBean("groceryStoreService",GroceryStoreService.class);
//		
//		Items item=new Items();
//		item.setItemId(1);
//		item.setItemName("orange");
//		item.setCategory("fruits");
//		item.setQuantity(10);
//		item.setRate(70);
//		
//		groceryStoreService.createItems(item);

	
	}

}
