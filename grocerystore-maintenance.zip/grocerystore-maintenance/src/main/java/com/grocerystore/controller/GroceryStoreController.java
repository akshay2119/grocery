package com.grocerystore.controller;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.grocerystore.entity.Items;
import com.grocerystore.service.GroceryStoreService;

@RestController
@RequestMapping(value="/grocery")
public class GroceryStoreController {
	@Autowired
	private GroceryStoreService groceryStoreService; 

	
	@PostMapping(value="/create")
	public Items createItems(@RequestBody Items item) {
		return groceryStoreService.createItems(item);
	}
	
	
	@GetMapping(value="/item/{itemid}")
	public Items getItemsByid(@PathVariable("itemid") Integer itemId) {
	return groceryStoreService.getItemsByid(itemId);
	}
	
	
	@GetMapping(value="/getall")
	public Iterable<Items> getAllItems(){
	return groceryStoreService.getAllItems();	
	}
	
	@GetMapping(value="/getall/cat")
	public ArrayList<Items> getItemsAccordingtoCat(@RequestParam("category") String category){
	return groceryStoreService.getItemsAccordingToCat(category);	
	}
	
	@PutMapping(value="/insert")
	public Items insertItems(@PathVariable("itemname") String itemname) {
		return groceryStoreService.insertItems(itemname);
	}

	@DeleteMapping(value="/item/{itemid}")
	public void deleteItemByid(@PathVariable("itemid") Integer itemId) {
		groceryStoreService.deletItemByid(itemId);
	}
	
	
	@DeleteMapping(value="/deleteall")
	public void deleteAll(@PathVariable("itemid") Integer itemId) {
		groceryStoreService.deleteAll(itemId);
	}
}



