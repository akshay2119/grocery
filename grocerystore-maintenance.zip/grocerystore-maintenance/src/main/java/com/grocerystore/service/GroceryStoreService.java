package com.grocerystore.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocerystore.dao.GroceryStoreDao;
import com.grocerystore.entity.Items;

@Service
public class GroceryStoreService {

	@Autowired
	private GroceryStoreDao groceryStoreDao;

	public Items createItems(Items item) {
		return groceryStoreDao.save(item);
	}

	public Items getItemsByid(Integer itemid) {
		return groceryStoreDao.findById(itemid).get();
	}

	public Iterable<Items> getAllItems() {
		return groceryStoreDao.findAll();
	}

	public ArrayList<Items> getItemsAccordingToCat(String category) {
		return groceryStoreDao.findByCategory(category);
	}

	public Items insertItems(String itemname) {
		return groceryStoreDao.save(itemname);
	}

	public void deletItemByid(Integer itemid) {

		groceryStoreDao.deleteById(itemid);
	}

	public void deleteAll(Integer itemId) {
		groceryStoreDao.deleteAll();

	}

}
