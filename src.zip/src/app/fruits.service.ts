import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FruitsService {

  constructor(private http: HttpClient) { }

  public urlFruit='grocerystore-maintenance/grocery/getall/cat/?category=fruits'
  public urlHomeApp='grocerystore-maintenance/grocery/getall/cat/?category=home application'
  public urlVegetables='grocerystore-maintenance/grocery/getall/cat/?category=vegetables'
   
  getAllfruits(): Observable<any> {
    return this.http.get(this.urlFruit).pipe(catchError(this.errorHandler));
  }

  getAllvegeteables(): Observable<any> {
    return this.http.get(this.urlVegetables).pipe(catchError(this.errorHandler));
  }
  
  getAllHomeApp(): Observable<any> {
    return this.http.get(this.urlHomeApp).pipe(catchError(this.errorHandler));
  }
  errorHandler(error: HttpErrorResponse) {
    return throwError('Server is down. Please try again later');
  }

}
