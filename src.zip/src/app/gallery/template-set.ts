export class TemplateSet {
    constructor(
        public name: string,
        public description: string,
        public imgUrl: string,
        public order: number,
    ) {

    }
}
