export interface Iuser {
    userName: any;
    userRole: any;
    name: any;
    email: any;
    avatarURL: any;
    totalPoints: any;
    followedTopics: any[];
    usersFollowing: any[];
    followers: any[];
    createdOn: Date;
    updatedOn: Date;
  }
  