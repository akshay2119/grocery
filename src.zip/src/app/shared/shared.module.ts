import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GroceryMaterialModule } from '../grocery-material.module';
import { AppRoutingModule } from '../app-routing.module';
import { CardsComponent } from './cards/cards.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    CardsComponent,
  ],
  entryComponents: [
    CardsComponent
  ],
  imports: [
    CommonModule,
    GroceryMaterialModule,
    AppRoutingModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    FormsModule
  ],
  exports: [
    CardsComponent,
  ]
})
export class SharedModule { }
