import { Component, OnInit } from '@angular/core';

import { Feature } from './feature';


@Component({
  selector: 'app-feature',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.scss']
})
export class FeaturesComponent implements OnInit {
  features: Feature[];

  constructor() { }

  ngOnInit() {
    this.features =
    [
      {
        name: 'Fruits',
        desc: 'Buy All fresh fruits',
        order: 1
      },
      {
        name: 'Vegetables',
        desc: 'Buy All fresh vegetables',
        order: 2
      },
      {
        name: 'Home Application',
        desc: 'All Home Applications',
        order: 3
      }
    ];
  }

}
