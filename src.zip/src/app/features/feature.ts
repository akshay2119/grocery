export class Feature {
    constructor(
        public name: string,
        public desc: string,
        public order: number
    ) {

    }
}
