import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GroceryMaterialModule} from './grocery-material.module';
import { SharedModule } from './shared/shared.module';
import { HomeModule} from './home/home.module';

import { FeaturesComponent } from './features/features.component';
import { BannerComponent } from './banner/banner.component';
import { GalleryComponent} from './gallery/gallery.component';
import { LoginComponent} from './login/login.component';
import { SidenavListComponent} from './side-nav/sidenav-list.component';
import { NavbarComponent} from './navbar/navbar.component';
import { FruitsComponent } from './fruits/fruits.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { VegetablesComponent } from './vegetables/vegetables.component';
import { HomeapplicationComponent } from './homeapplication/homeapplication.component';
import { DashboardComponent } from './home/dashboard/dashboard.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    FruitsComponent,
    HeaderComponent,
    FooterComponent,
    FeaturesComponent,
    LoginComponent,
    SidenavListComponent,
    NavbarComponent,
    BannerComponent,
    GalleryComponent,
    VegetablesComponent,
    HomeapplicationComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    GroceryMaterialModule,
    SharedModule,
    HomeModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [DashboardComponent]
})
export class AppModule { }
