import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FruitsComponent } from './fruits/fruits.component';
import { Router } from '@angular/router';
import { DashboardComponent} from './home/dashboard/dashboard.component';
import { VegetablesComponent } from './vegetables/vegetables.component';
import { HomeapplicationComponent } from './homeapplication/homeapplication.component';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent, pathMatch: 'full'},
  { path: 'fruits', component: FruitsComponent, pathMatch: 'full'},
  { path: 'vegetables', component: VegetablesComponent, pathMatch: 'full'} ,
  { path: 'homeapplication', component: HomeapplicationComponent, pathMatch: 'full'}  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
