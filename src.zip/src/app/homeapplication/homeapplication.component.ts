import { Component, OnInit } from '@angular/core';
import { FruitsService } from '../fruits.service';

@Component({
  selector: 'app-homeapplication',
  templateUrl: './homeapplication.component.html',
  styleUrls: ['./homeapplication.component.scss']
})
export class HomeapplicationComponent implements OnInit {

  constructor(private fruits: FruitsService,) { }
  displayedColumns: string[] = ['itemId', 'itemName', 'category', 'quantity','rate'];
  
  private homeAppData: any;
  public dataSource= [];

  ngOnInit() {
    this.fruits.getAllHomeApp().subscribe(mydata => {
      this.homeAppData = mydata;
      console.log('vegetables:',this.homeAppData);
      this.dataSource = this.homeAppData;
      console.log('dataSource::',this.dataSource);
    });
  }

}
